This is a Symfony flex skeleton for a minimal Symfony AgVoy app
project, used for teaching CSC4101 at Telecom SudParis.

Composer packages can be found at
https://packagist.org/packages/oberger/tspcsc4101-agvoy-skeleton

Code is available at :
https://gitlab.com/olberger/tspcsc4101-agvoy-skeleton

To test, use :
 $ composer create-project oberger/tspcsc4101-agvoy-skeleton agvoy-app

-- Olivier Berger
# AgenceVoyageTSP
